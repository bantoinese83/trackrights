import { NextRequest, NextResponse } from 'next/server';
import { GoogleGenerativeAI } from '@google/generative-ai';

const getApiKey = (): string => {
  const envApiKey = process.env.GEMINI_API_KEY;
  if (envApiKey) {
    return envApiKey;
  }
  console.warn('GEMINI_API_KEY not found in environment variables. Using fallback key.');
  return 'AIzaSyDmxvr6uXs_WyDnwqNiJ4QynI67vJUuj10';
};

const apiKey = getApiKey();
const genAI = new GoogleGenerativeAI(apiKey);
const model = genAI.getGenerativeModel({ model: 'models/gemini-2.0-flash-exp' });

const SYSTEM_MESSAGE = `You are an expert seasoned music industry lawyer specialized in revising music industry contracts in favor of music producers. Your task is to rewrite the given contract based on the provided instructions, making it more favorable for the producer while still maintaining a fair and legal agreement. Follow these guidelines:

1. Carefully analyze the original contract and the revision instructions.
2. Identify key areas where the contract can be improved for the producer's benefit.
3. Rewrite relevant clauses to align with the producer's interests, as per the instructions.
4. Ensure that the revised contract remains legally sound and doesn't introduce unfair or unethical terms.
5. Maintain a professional and formal tone throughout the revised contract.
6. Highlight any significant changes you've made in the revision process.

Format your response using standard contract structure and language. Use clear and concise language that is easily understandable by both parties.`;

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const MAX_RETRIES = 5;
const BASE_DELAY = 1000; // 1 second

async function generateWithRetry(content: string[], retryCount = 0): Promise<string> {
  try {
    const result = await model.generateContent(content);
    return result.response.text();
  } catch (error: unknown) {
    if (error instanceof Error && 'status' in error && (error as { status: number }).status &&
          (error.status === 429 || error.status === 503) && retryCount < MAX_RETRIES) {
      const waitTime = BASE_DELAY * Math.pow(2, retryCount);
      console.log(`Service unavailable. Retrying in ${waitTime}ms...`);
      await delay(waitTime);
      return generateWithRetry(content, retryCount + 1);
    }
    throw error;
  }
}

const handleError = (error: unknown): { errorMessage: string, statusCode: number } => {
  console.error('Error revising contract:', error);
  let errorMessage = 'Failed to revise the contract';
  let statusCode = 500;

  if (error instanceof Error && (error as { status?: number }).status === 429) {
    errorMessage = 'API rate limit exceeded. Please try again later.';
    statusCode = 429;
  } else if (error instanceof Error && (error as { status?: number }).status === 403) {
    errorMessage = 'API access forbidden. Please check your API key.';
    statusCode = 403;
  } else if (error instanceof Error && (error as { status?: number }).status === 503) {
    errorMessage = 'Service unavailable. Please try again later.';
    statusCode = 503;
  }

  return { errorMessage, statusCode };
};

export async function POST(req: NextRequest) {
  if (req.headers.get('content-type') !== 'application/json') {
    return NextResponse.json({ error: 'Invalid content type' }, { status: 400 });
  }

  try {
    const { originalContract, instructions } = await req.json();

    if (!originalContract || !instructions) {
      return NextResponse.json({ error: 'Missing original contract or instructions' }, { status: 400 });
    }

    const content = [
      SYSTEM_MESSAGE,
      `Original Contract: ${originalContract}`,
      `Revision Instructions: ${instructions}`,
      'Please revise the contract based on the given instructions, making it more favorable for the producer.'
    ];

    const revisedContract = await generateWithRetry(content);

    return NextResponse.json({ revisedContract }, { status: 200 });
  } catch (error: unknown) {
    const { errorMessage, statusCode } = handleError(error);
    return NextResponse.json({ error: errorMessage }, { status: statusCode });
  }
}

