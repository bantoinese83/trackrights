import { NextRequest, NextResponse } from 'next/server'
import { GoogleGenerativeAI } from '@google/generative-ai'

const getApiKey = () => {
  const envApiKey = process.env.GEMINI_API_KEY
  if (envApiKey) {
    return envApiKey
  }
  console.warn('GEMINI_API_KEY not found in environment variables. Using fallback key.')
  return 'AIzaSyDmxvr6uXs_WyDnwqNiJ4QynI67vJUuj10'
}

const apiKey = getApiKey()
const genAI = new GoogleGenerativeAI(apiKey)
const model = genAI.getGenerativeModel({ model: 'models/gemini-2.0-flash-exp' })
const SYSTEM_MESSAGE = `You are an expert business lawyer specializing in contract law. Your task is to create a comprehensive and professional contract based on the provided details. Follow these guidelines:

1. Contract Overview:
   - Use the provided party names, project title,effective date,payment terms, and other details.
   - Summarize the main purpose of the contract in 2-3 sentences.
   - State the effective date and duration of the agreement.

2. Key Terms and Definitions:
   - List and explain important terms defined in the contract.
   - Highlight any industry-specific jargon and provide clear explanations.

3. Rights and Obligations:
   - Outline the main rights granted to each party.
   - Detail the key obligations of each party.
   - Identify any exclusive rights or restrictions.

4. Financial Terms:
   - Explain the payment structure (e.g., advances, royalties, profit sharing).
   - Highlight any minimum guarantees or performance bonuses.
   - Clarify how and when payments are to be made.

5. Intellectual Property:
   - Describe how copyright and other IP rights are handled.
   - Explain any licensing or assignment of rights.

6. Term and Termination:
   - Clarify the duration of the agreement.
   - Explain conditions for renewal or extension.
   - Outline the circumstances under which the contract can be terminated.

7. Confidentiality:
   - Detail the confidentiality obligations of each party.
   - Specify the duration of confidentiality obligations post-termination.

8. Dispute Resolution:
   - Outline the process for resolving disputes (e.g., mediation, arbitration).
   - Specify the governing law and jurisdiction.

9. Amendments:
   - Explain the process for making amendments to the contract.
   - Specify any conditions or approvals required for amendments.

10. Miscellaneous:
    - Include any other significant clauses (e.g., force majeure, assignment, notices).
    - Ensure all clauses are clear and enforceable.

Format your response using standard contract structure and language. Use clear and concise language that is easily understandable by both parties. Ensure the contract is complete and professional.`
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms))

const MAX_RETRIES = 5
const BASE_DELAY = 1000 // 1 second

async function generateWithRetry(content: any[], retryCount = 0): Promise<string> {
  try {
    const result = await model.generateContent(content)
    return result.response.text()
  } catch (error: any) {
    if ((error.status === 429 || error.status === 503) && retryCount < MAX_RETRIES) {
      const waitTime = BASE_DELAY * Math.pow(2, retryCount)
      console.log(`Service unavailable. Retrying in ${waitTime}ms...`)
      await delay(waitTime)
      return generateWithRetry(content, retryCount + 1)
    }
    throw error
  }
}

export async function POST(req: NextRequest) {
  try {
    if (req.headers.get('content-type') !== 'application/json') {
      return NextResponse.json({ error: 'Invalid content type' }, { status: 400 })
    }

    const { contractDetails, contractInputs } = await req.json()

    if (!contractDetails || !contractInputs) {
      return NextResponse.json({ error: 'Missing contract details or inputs' }, { status: 400 })
    }

    const content = [
      SYSTEM_MESSAGE,
      `Contract Details: ${JSON.stringify(contractDetails)}`,
      `Contract Inputs: ${JSON.stringify(contractInputs)}`,
      'Generate a comprehensive and professional contract based on the provided details and inputs.',
    ]

    const generatedContract = await generateWithRetry(content)

    return NextResponse.json({ generatedContract }, { status: 200 })
  } catch (error: any) {
    console.error('Error generating contract:', error)
    let errorMessage = 'Failed to generate the contract'
    let statusCode = 500

    if (error.status === 429) {
      errorMessage = 'API rate limit exceeded. Please try again later.'
      statusCode = 429
    } else if (error.status === 403) {
      errorMessage = 'API access forbidden. Please check your API key.'
      statusCode = 403
    } else if (error.status === 503) {
      errorMessage = 'Service unavailable. Please try again later.'
      statusCode = 503
    }

    return NextResponse.json({ error: errorMessage }, { status: statusCode })
  }
}

