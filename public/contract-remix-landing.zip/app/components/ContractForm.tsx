'use client'

import React, { useState, useEffect } from 'react'
import { Plus, Trash2, ChevronDown, ChevronUp, X, GripVertical } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Contract } from '@/lib/contracts'
import { useToast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"
import { useSortable } from '@dnd-kit/sortable';
import {
    DndContext,
    DragOverlay,
    closestCenter,
    KeyboardSensor,
    PointerSensor,
    useSensor,
    useSensors
} from '@dnd-kit/core';

interface Party {
    name: string
    title: string
    [key: string]: string
}

interface CustomField {
    id: string;
    name: string
    type: 'text' | 'number' | 'date' | 'textarea' | 'boolean'
    label: string
    defaultValue?: string | number | boolean
    placeholder?: string;
    required?: boolean;
}

export interface ContractInputs {
    parties: Party[]
    projectTitle: string
    effectiveDate: string
    customFields: Record<string, string | number | boolean>
    tags: string[]
}

interface ContractFormProps {
    contract: Contract
    onSubmitAction: (contractInputs: ContractInputs) => void
}

const initialCustomFields: Record<string, CustomField[]> = {
    licensing: [
        { id: 'licenseType', name: 'licenseType', type: 'text', label: 'License Type', placeholder: 'Enter the license type' },
        { id: 'royaltyRate', name: 'royaltyRate', type: 'number', label: 'Royalty Rate (%)', placeholder: 'Enter royalty rate' },
    ],
    studio: [
        { id: 'studioRate', name: 'studioRate', type: 'number', label: 'Studio Rate (per hour)', placeholder: 'Enter rate per hour' },
        { id: 'equipmentIncluded', name: 'equipmentIncluded', type: 'textarea', label: 'Equipment Included', placeholder: 'List included equipment' }
    ],
    default: []
}


export function ContractForm({ contract, onSubmitAction }: ContractFormProps) {
    const [contractInputs, setContractInputs] = useState<ContractInputs>({
        parties: [{ name: '', title: '' }],
        projectTitle: '',
        effectiveDate: '',
        customFields: {},
        tags: []
    })

    const [customFields, setCustomFields] = useState<CustomField[]>([])
    const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
        parties: true,
        projectDetails: true,
        customFields: true,
        tags: true
    })
    const { toast } = useToast()
    const [newTag, setNewTag] = useState('');
    const [activeId, setActiveId] = useState<string | null>(null);


    const sensors = useSensors(
        useSensor(PointerSensor),
        useSensor(KeyboardSensor, {
            coordinateGetter: closestCenter,
        })
    );


    useEffect(() => {
        const categoryFields = initialCustomFields[contract.category] || initialCustomFields.default;
        setCustomFields(categoryFields.map(field => ({ ...field, id: field.id || `customField-${Math.random()}` })));
        setContractInputs(prevInputs => ({
            ...prevInputs,
            customFields: categoryFields.reduce((acc, field) => {
                acc[field.name] = field.defaultValue || '';
                return acc;
            }, {} as Record<string, string | number | boolean>)
        }));
    }, [contract.category]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>, index?: number, field?: string) => {
        const { name, value, type, checked } = e.target
        const typedValue = type === 'number' ? Number(value) : type === 'checkbox' ? checked : value;
        if (index !== undefined && field) {
            setContractInputs(prev => ({
                ...prev,
                parties: prev.parties.map((party, i) =>
                    i === index ? { ...party, [field]: value } : party
                )
            }))
        } else if (name in contractInputs) {
            setContractInputs(prev => ({ ...prev, [name]: value }))
        } else {
            setContractInputs(prev => ({
                ...prev,
                customFields: { ...prev.customFields, [name]: typedValue }
            }))
        }
    }


    const handleSwitchChange = (name: string, checked: boolean) => {
        setContractInputs(prev => ({
            ...prev,
            customFields: { ...prev.customFields, [name]: checked }
        }))
    }


    const handleCustomFieldChange = (index: number, field: string, value: any) => {
        setCustomFields(prev =>
            prev.map((item, i) =>
                i === index ? { ...item, [field]: value } : item
            )
        )
    };


    const addParty = () => {
        setContractInputs(prev => ({
            ...prev,
            parties: [...prev.parties, { name: '', title: '' }]
        }))
    }

    const removeParty = (index: number) => {
        setContractInputs(prev => ({
            ...prev,
            parties: prev.parties.filter((_, i) => i !== index)
        }))
    }

    const addCustomField = () => {
        const newField = {
            id: `customField-${Math.random()}`,
            name: `customField${customFields.length}`,
            type: 'text',
            label: `Custom Field ${customFields.length + 1}`,
        };
        setCustomFields(prev => [...prev, newField])
        setContractInputs(prev => ({
            ...prev,
            customFields: { ...prev.customFields, [newField.name]: '' }
        }))
    }


    const removeCustomField = (index: number) => {
        setCustomFields(prev => prev.filter((_, i) => i !== index))
        setContractInputs(prev => {
            const { [`customField${index}`]: _, ...rest } = prev.customFields
            return { ...prev, customFields: rest }
        });
    };


    const toggleSection = (section: string) => {
        setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }))
    };

    const handleTagInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setNewTag(e.target.value);
    };

    const addTag = () => {
        if (newTag.trim() && !contractInputs.tags.includes(newTag.trim())) {
            setContractInputs((prev) => ({
                ...prev,
                tags: [...prev.tags, newTag.trim()],
            }));
            setNewTag('');
        }
    };

    const removeTag = (tagToRemove: string) => {
        setContractInputs((prev) => ({
            ...prev,
            tags: prev.tags.filter((tag) => tag !== tagToRemove),
        }));
    };

    const validateForm = (): boolean => {
        if (contractInputs.parties.some(party => !party.name || !party.title)) {
            toast({
                title: "Missing Information",
                description: "Please fill in all party details.",
                variant: "destructive",
            })
            return false
        }
        if (!contractInputs.projectTitle || !contractInputs.effectiveDate) {
            toast({
                title: "Missing Information",
                description: "Please fill in the project title and effective date.",
                variant: "destructive",
            })
            return false
        }

        for (const field of customFields) {
            if (field.required && !contractInputs.customFields[field.name]) {
                toast({
                    title: "Missing Information",
                    description: `Please fill in the ${field.label} field.`,
                    variant: "destructive",
                })
                return false;
            }
        }

        return true
    }


    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault()
        if (validateForm()) {
            onSubmitAction(contractInputs)
        }
    }

    const handleDragEnd = (event: any) => {
        const { active, over } = event;

        if (active.id !== over?.id) {
            setCustomFields((items) => {
                const activeIndex = items.findIndex(item => item.id === active.id);
                const overIndex = items.findIndex(item => item.id === over?.id);
                if (activeIndex === -1 || overIndex === -1) return items;
                return arrayMove(items, activeIndex, overIndex);
            })

        }
        setActiveId(null);
    }

    return (
        <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragStart={(event) => { setActiveId(event.active.id); }}
            onDragEnd={handleDragEnd}
        >
            <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-4">
                    <Button
                        type="button"
                        variant="ghost"
                        onClick={() => toggleSection('parties')}
                        className={`w-full flex justify-between items-center p-3 rounded-md hover:bg-gray-100 ${expandedSections.parties ? 'bg-gray-100' : ''}`}
                    >
                        <span className="font-semibold text-lg">Parties</span>
                        {expandedSections.parties ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                    </Button>
                    {expandedSections.parties && (
                        <div className="space-y-4">
                            {contractInputs.parties.map((party, index) => (
                                <div key={index} className="space-y-2 p-4 bg-gray-50 rounded-md">
                                    <div className="flex items-center justify-between">
                                        <h4 className="text-md font-semibold">Party {index + 1}</h4>
                                        {index > 0 && (
                                            <Button
                                                type="button"
                                                variant="ghost"
                                                size="sm"
                                                onClick={() => removeParty(index)}
                                                className="text-red-500 hover:text-red-700"
                                            >
                                                <Trash2 className="h-4 w-4 mr-1" />
                                                Remove
                                            </Button>
                                        )}
                                    </div>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <Label htmlFor={`party-name-${index}`}>Name</Label>
                                            <Input
                                                id={`party-name-${index}`}
                                                value={party.name}
                                                onChange={(e) => handleInputChange(e, index, 'name')}
                                                placeholder="Enter party name"
                                                required
                                            />
                                        </div>
                                        <div>
                                            <Label htmlFor={`party-title-${index}`}>Title</Label>
                                            <Input
                                                id={`party-title-${index}`}
                                                value={party.title}
                                                onChange={(e) => handleInputChange(e, index, 'title')}
                                                placeholder="Enter party title"
                                                required
                                            />
                                        </div>
                                    </div>
                                </div>
                            ))}
                            <Button
                                type="button"
                                variant="outline"
                                onClick={addParty}
                                className="w-full text-purple-600 hover:text-purple-700 border-purple-600 hover:border-purple-700"
                            >
                                <Plus className="h-4 w-4 mr-2" />
                                Add Another Party
                            </Button>
                        </div>
                    )}
                </div>


                <div className="space-y-4">
                    <Button
                        type="button"
                        variant="ghost"
                        onClick={() => toggleSection('projectDetails')}
                        className={`w-full flex justify-between items-center p-3 rounded-md hover:bg-gray-100 ${expandedSections.projectDetails ? 'bg-gray-100' : ''}`}
                    >
                        <span className="font-semibold text-lg">Project Details</span>
                        {expandedSections.projectDetails ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                    </Button>
                    {expandedSections.projectDetails && (
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <Label htmlFor="projectTitle">Project Title</Label>
                                <Input
                                    id="projectTitle"
                                    name="projectTitle"
                                    value={contractInputs.projectTitle}
                                    onChange={handleInputChange}
                                    placeholder="Enter project title"
                                    required
                                />
                            </div>
                            <div>
                                <Label htmlFor="effectiveDate">Effective Date</Label>
                                <Input
                                    id="effectiveDate"
                                    name="effectiveDate"
                                    type="date"
                                    value={contractInputs.effectiveDate}
                                    onChange={handleInputChange}
                                    required
                                />
                            </div>
                        </div>
                    )}
                </div>
                <div className="space-y-4">
                    <Button
                        type="button"
                        variant="ghost"
                        onClick={() => toggleSection('customFields')}
                        className={`w-full flex justify-between items-center p-3 rounded-md hover:bg-gray-100 ${expandedSections.customFields ? 'bg-gray-100' : ''}`}
                    >
                        <span className="font-semibold text-lg">Additional Details</span>
                        {expandedSections.customFields ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                    </Button>
                    {expandedSections.customFields && (
                        <div className="space-y-4">
                            {customFields.map((field, index) => (
                                  <SortableItem key={field.id} id={field.id}>
                                      <div className="relative p-4 bg-gray-50 rounded-md  border border-gray-200">
                                        <div className="flex items-center justify-between mb-4">
                                                <Label htmlFor={field.name}>{field.label}</Label>
                                                <div className="flex space-x-2">
                                                    <Button type="button" variant="ghost" size="icon" onClick={() => removeCustomField(index)} className="text-red-500 hover:text-red-700">
                                                        <Trash2 className="w-4 h-4" />
                                                    </Button>
                                                    <div className="cursor-grab active:cursor-grabbing">
                                                        <GripVertical className="w-4 h-4" />
                                                    </div>
                                                </div>
                                            </div>
                                        <div className="grid grid-cols-2 gap-4">
                                                <div>
                                                    <Label htmlFor={`${field.name}-type`}>Type</Label>
                                                    <select
                                                        id={`${field.name}-type`}
                                                        className="w-full border rounded p-2 bg-white"
                                                        value={field.type}
                                                        onChange={(e) => handleCustomFieldChange(index, 'type', e.target.value)}
                                                    >
                                                        <option value="text">Text</option>
                                                        <option value="number">Number</option>
                                                        <option value="date">Date</option>
                                                        <option value="textarea">Text Area</option>
                                                        <option value="boolean">Boolean</option>
                                                    </select>
                                                </div>
                                                <div>
                                                    <Label htmlFor={`${field.name}-label`}>Label</Label>
                                                    <Input
                                                        id={`${field.name}-label`}
                                                        type="text"
                                                        value={field.label}
                                                        onChange={(e) => handleCustomFieldChange(index, 'label', e.target.value)}
                                                        placeholder="Enter label text"
                                                    />
                                                </div>
                                            </div>
                                        <div className="space-y-2 mt-2">
                                             <Label htmlFor={field.name}>{field.label} Input</Label>
                                            {field.type === 'textarea' ? (
                                                <Textarea
                                                    id={field.name}
                                                    name={field.name}
                                                    value={contractInputs.customFields[field.name] as string || ''}
                                                    onChange={handleInputChange}
                                                    placeholder={field.placeholder || `Enter ${field.label.toLowerCase()}`}
                                                />
                                            ) : field.type === 'boolean' ? (
                                                <div className="flex items-center space-x-2">
                                                    <Switch
                                                        id={field.name}
                                                        checked={contractInputs.customFields[field.name] as boolean || false}
                                                        onCheckedChange={(checked) => handleSwitchChange(field.name, checked)}
                                                    />
                                                    <Label htmlFor={field.name}>Yes</Label>
                                                </div>
                                            ) : (
                                                <Input
                                                    id={field.name}
                                                    name={field.name}
                                                    type={field.type}
                                                    value={contractInputs.customFields[field.name] as string || ''}
                                                    onChange={handleInputChange}
                                                    placeholder={field.placeholder || `Enter ${field.label.toLowerCase()}`}
                                                />
                                            )}
                                            <div className="flex gap-4 mt-2">
                                                <div>
                                                    <Label htmlFor={`${field.name}-defaultValue`}>Default Value</Label>
                                                    <Input
                                                        id={`${field.name}-defaultValue`}
                                                        type="text"
                                                        value={field.defaultValue as string || ''}
                                                        onChange={(e) => handleCustomFieldChange(index, 'defaultValue', e.target.value)}
                                                        placeholder="Set Default Value"
                                                    />
                                                </div>
                                                <div>
                                                    <div className="flex items-center space-x-2">
                                                        <Label htmlFor={`${field.name}-required`}>Required</Label>
                                                        <Switch
                                                            id={`${field.name}-required`}
                                                            checked={field.required || false}
                                                            onCheckedChange={(checked) => handleCustomFieldChange(index, 'required', checked)}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                   </SortableItem>
                            ))}
                             <DragOverlay>
                        {activeId ? (
                                <div className="relative p-4 bg-gray-50 rounded-md  border border-gray-200">
                                  {customFields.find(item=> item.id === activeId)?.label}
                                   </div>
                              ) : null}
                   </DragOverlay>
                            <Button
                                type="button"
                                variant="outline"
                                onClick={addCustomField}
                                className="w-full text-purple-600 hover:text-purple-700 border-purple-600 hover:border-purple-700"
                            >
                                <Plus className="h-4 w-4 mr-2" />
                                Add Custom Field
                            </Button>
                        </div>
                    )}
                </div>
                <div className="space-y-4">
                    <Button
                        type="button"
                        variant="ghost"
                        onClick={() => toggleSection('tags')}
                       className={`w-full flex justify-between items-center p-3 rounded-md hover:bg-gray-100 ${expandedSections.tags ? 'bg-gray-100' : ''}`}
                    >
                        <span className="font-semibold text-lg">Tags</span>
                        {expandedSections.tags ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                    </Button>
                    {expandedSections.tags && (
                        <div className="space-y-2">
                            <div className="flex space-x-2">
                                <Input
                                    type="text"
                                    placeholder="Add a tag..."
                                    value={newTag}
                                    onChange={handleTagInputChange}
                                />
                                <Button type="button" variant="outline" size="sm" onClick={addTag}>Add</Button>
                            </div>
                            <div className="flex flex-wrap gap-2 mt-2">
                                {contractInputs.tags.map((tag, index) => (
                                    <Badge key={index} variant="secondary" className="relative">
                                        {tag}
                                        <Button
                                            type="button"
                                            variant="ghost"
                                            size="icon"
                                            onClick={() => removeTag(tag)}
                                            className="absolute top-0 right-0"
                                        >
                                            <X className="w-3 h-3" />
                                        </Button>
                                    </Badge>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
                <Button
                    type="submit"
                    className="w-full bg-purple-600 hover:bg-purple-700 text-white"
                >
                    Generate Contract
                </Button>
            </form>
        </DndContext>
    )
}
    function SortableItem(props:any) {
    const {
      attributes,
      listeners,
      setNodeRef,
        transform,
      transition,
    } = useSortable({id: props.id});

    const style = {
        transform: transform ? `translate3d(${transform.x}px, ${transform.y}px, 0)` : undefined,
        transition
    }

        return (
            <div ref={setNodeRef} style={style} {...attributes} {...listeners}>
                {props.children}
            </div>
        )
}

    function arrayMove<T>(array:T[], from: number, to: number): T[] {
  const newArray = [...array];
  const startIndex = from < 0 ? newArray.length + from : from;
  if (startIndex >= 0 && startIndex < newArray.length) {
    const endIndex = to < 0 ? newArray.length + to : to;
    if (endIndex >= 0 && endIndex < newArray.length) {
      const [item] = newArray.splice(startIndex, 1);
      newArray.splice(endIndex, 0, item);
    }
  }
  return newArray;
}

