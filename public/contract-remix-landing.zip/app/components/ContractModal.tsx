'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { X } from 'lucide-react'
import { Button } from "@/components/ui/button"
import { Contract } from '@/lib/contracts'
import { useToast } from "@/components/ui/use-toast"
import { GenerateContractIndicator } from './GenerateContractIndicator'
import { Skeleton } from "@/components/ui/skeleton"
import { ContractForm, ContractInputs } from './ContractForm'

interface ContractModalProps {
  contract: Contract;
  onClose: () => void;
}

export function ContractModal({ contract, onClose }: ContractModalProps) {
  const [generatedContract, setGeneratedContract] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const handleGenerateContract = async (contractInputs: ContractInputs) => {
    setIsLoading(true)
    try {
      const response = await fetch('/api/generate-contract', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contractDetails: contract,
          contractInputs,
        }),
      })

      if (!response.ok) {
        throw new Error('Failed to generate contract')
      }

      const data = await response.json()
      setGeneratedContract(data.generatedContract)
      toast({
        title: "Contract Generated",
        description: "Your contract has been successfully generated.",
      })
    } catch (error) {
      console.error('Error:', error)
      toast({
        title: "Error",
        description: "Failed to generate the contract. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 overflow-y-auto"
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        className="bg-white rounded-lg p-6 w-full max-w-3xl max-h-[90vh] overflow-y-auto"
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold text-purple-800">{contract.title}</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-6 w-6" />
          </Button>
        </div>
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-2">Description:</h3>
          <p className="text-gray-700">{contract.description}</p>
        </div>
        {!generatedContract ? (
          <ContractForm contract={contract} onSubmitAction={handleGenerateContract} />
        ) : (
          <div>
            <h3 className="text-lg font-semibold mb-2">Generated Contract:</h3>
            {isLoading ? (
              <div className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
              </div>
            ) : (
              <pre className="bg-gray-100 p-4 rounded-md overflow-x-auto whitespace-pre-wrap">
                {generatedContract}
              </pre>
            )}
          </div>
        )}
        {isLoading && <GenerateContractIndicator />}
      </motion.div>
    </motion.div>
  )
}

