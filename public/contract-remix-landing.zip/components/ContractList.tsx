'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Search, ChevronDown, ChevronUp, FileText } from 'lucide-react'
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface Contract {
  id: string;
  title: string;
  category: 'featured' | 'producer' | 'licensing' | 'studio' | 'other';
  tags?: string[];
}

const contracts: Contract[] = [
  { id: 'mpc', title: 'Music Producer Contract Package', category: 'featured', tags: ['comprehensive'] },
  { id: 'fa1', title: 'Featured Artist Agreement 1 (No Royalty/Song Rights)', category: 'featured' },
  { id: 'fa2', title: 'Featured Artist Agreement 2 (Royalty/No Song Rights)', category: 'featured' },
  { id: 'fa3', title: 'Featured Artist Agreement 3 (Royalty/Song Rights)', category: 'featured' },
  { id: 'lod', title: 'Letter of Direction (To Record Company)', category: 'other' },
  { id: 'mul1', title: 'Master Use License (Audiovisual Work)', category: 'licensing' },
  { id: 'mul2', title: 'Master Use License (Compilation)', category: 'licensing' },
  { id: 'ml', title: 'Mechanical License', category: 'licensing' },
  { id: 'pcg', title: 'Parental Consent and Guarantee (Used with Minors)', category: 'other' },
  { id: 'pada', title: 'Producer and Artist Development Agreement', category: 'producer' },
  { id: 'papa', title: 'Producer and Artist Production Agreement', category: 'producer' },
  { id: 'ppca', title: 'Producer and Production Company Agreement', category: 'producer' },
  { id: 'prcpa', title: 'Producer and Record Company Production Agreement', category: 'producer' },
  { id: 'pd', title: 'Producer Declaration', category: 'producer' },
  { id: 'pt1a', title: 'Producer of Tracks 1-Artist (No Royalty/Song Rights)', category: 'producer' },
  { id: 'pt2a', title: 'Producer of Tracks 2-Artist (No Royalty/No Song Rights)', category: 'producer' },
  { id: 'pt3a', title: 'Producer of Tracks 3-Artist (Royalty/Song Rights)', category: 'producer' },
  { id: 'pt4a', title: 'Producer of Tracks 4-Artist (Royalty/No Song Rights)', category: 'producer' },
  { id: 'pt1l', title: 'Producer of Tracks 1-Label (No Royalty/Song Rights)', category: 'producer' },
  { id: 'pt2l', title: 'Producer of Tracks 2-Label (No Royalty/No Song Rights)', category: 'producer' },
  { id: 'pt3l', title: 'Producer of Tracks 3-Label (Royalty/Song Rights)', category: 'producer' },
  { id: 'pt4l', title: 'Producer of Tracks 4-Label (Royalty/No Song Rights)', category: 'producer' },
  { id: 'ptla', title: 'Producer of Tracks License Agreement (Non-Exclusive)', category: 'licensing' },
  { id: 'rea', title: 'Recording Engineer Agreement', category: 'studio' },
  { id: 'rsra', title: 'Recording Studio Rental Agreement', category: 'studio' },
  { id: 'rpa', title: 'Release From Production Agreement', category: 'producer' },
  { id: 'saa', title: 'Side Artist Agreement (No Royalty/No Song Rights)', category: 'other' },
]

const categories = {
  featured: 'Featured Contracts',
  producer: 'Producer Agreements',
  licensing: 'Licensing',
  studio: 'Studio Agreements',
  other: 'Other Documents'
}

export function ContractList() {
  const [searchQuery, setSearchQuery] = useState('')
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({
    featured: true,
    producer: true,
    licensing: true,
    studio: true,
    other: true
  })

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [category]: !prev[category]
    }))
  }

  const filteredContracts = contracts.filter(contract =>
    contract.title.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const groupedContracts = filteredContracts.reduce((acc, contract) => {
    if (!acc[contract.category]) {
      acc[contract.category] = []
    }
    acc[contract.category].push(contract)
    return acc
  }, {} as Record<string, Contract[]>)

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-8">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <Input
            type="text"
            placeholder="Search contracts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-4 py-2 w-full border rounded-md focus:ring-2 focus:ring-purple-500"
          />
        </div>
      </div>

      {Object.entries(categories).map(([category, title]) => {
        const categoryContracts = groupedContracts[category]
        if (!categoryContracts?.length) return null

        return (
          <motion.div
            key={category}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="mb-6"
          >
            <Button
              variant="ghost"
              onClick={() => toggleCategory(category)}
              className="w-full flex justify-between items-center p-4 bg-purple-50 hover:bg-purple-100 rounded-lg mb-2"
            >
              <h2 className="text-lg font-semibold text-purple-900">{title}</h2>
              {expandedCategories[category] ? (
                <ChevronUp className="h-5 w-5 text-purple-600" />
              ) : (
                <ChevronDown className="h-5 w-5 text-purple-600" />
              )}
            </Button>

            <motion.div
              initial={false}
              animate={{
                height: expandedCategories[category] ? 'auto' : 0,
                opacity: expandedCategories[category] ? 1 : 0
              }}
              transition={{ duration: 0.3 }}
              className="overflow-hidden"
            >
              <div className="space-y-2">
                {categoryContracts.map((contract) => (
                  <motion.div
                    key={contract.id}
                    whileHover={{ scale: 1.01 }}
                    className="p-4 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow border border-gray-100"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3">
                        <FileText className="h-5 w-5 text-purple-500 mt-1 flex-shrink-0" />
                        <div>
                          <h3 className="text-gray-900">{contract.title}</h3>
                          {contract.tags && (
                            <div className="mt-2 flex gap-2">
                              {contract.tags.map(tag => (
                                <Badge key={tag} variant="secondary" className="bg-purple-100 text-purple-800">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-purple-600 hover:text-purple-700"
                      >
                        View
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )
      })}

      {!Object.keys(groupedContracts).length && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-8 text-gray-500"
        >
          No contracts found matching your search.
        </motion.div>
      )}
    </div>
  )
}

